# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Earendill",
    "author" : "jeeltcraft", 
    "description" : "Addon to mint on Mintbase",
    "blender" : (3, 0, 0),
    "version" : (1, 0, 0),
    "location" : "",
    "warning" : "",
    "doc_url": "earendill.varda.vision", 
    "tracker_url": "", 
    "category" : "User Interface" 
}


import bpy
import bpy.utils.previews
from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
import near_api
import requests


addon_keymaps = {}
_icons = None
class SNA_OT_Mint_Unlockable_F758D(bpy.types.Operator):
    bl_idname = "sna.mint_unlockable_f758d"
    bl_label = "mint unlockable"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        media = bpy.context.scene.sna_render
        unlock = bpy.context.scene.sna_source
        title = bpy.context.scene.sna_title
        description = bpy.context.scene.sna_description
        contract_id = bpy.context.scene.sna_store
        addrss = bpy.context.scene.sna_account
        num_to_mint = bpy.context.scene.sna_copies
        import time
        from selenium.webdriver.chrome.service import Service
        # Import the near_api module from local folder
        # Import http requests and json utilities to lock the main file
        # The URL for the near wallet
        NEAR_WALLET_URL = "https://wallet.near.org/"
        # The format for the key in local storage
        KEY_FMT = "nearlib:keystore:{addrss}:default"
        # This is the variable that will contain the private key if found
        private_key = None
        # get wallet key def

        def get_private_key(driver, addrss):
            key = KEY_FMT.format(addrss=addrss)
            return driver.execute_script(f'return window.localStorage.getItem("{key}")')
        # minting function def

        def mint_render(addrss, private_key):
            contract_id = bpy.context.scene.sna_store
            signer_id = bpy.context.scene.sna_account
            signer_key = private_key
            near_provider = near_api.providers.JsonProvider("https://rpc.near.org")
            key_pair = near_api.signer.KeyPair(signer_key)
            signer = near_api.signer.Signer(signer_id, key_pair)
            account = near_api.account.Account(near_provider, signer, signer_id)
            tknmeta = {"title": bpy.context.scene.sna_title, "description": bpy.context.scene.sna_description,
                       "media": bpy.context.scene.sna_render}
            args = {"owner_id": signer_id, "num_to_mint": bpy.context.scene.sna_copies, "metadata": tknmeta, "royalty_args": None,
                    "split_owners": None }
            gas = 200000000000000
            amount = 200000000000000
            # Print the private key
            print("\nPrivate Key: " + private_key)
            # Mint action call
            account.function_call(contract_id, "nft_batch_mint", args, gas, amount)
            print("minted!")
        # Get the near address from user
        addrss = bpy.context.scene.sna_account
        # Open the chrome browser (install chromedriver if required)
        driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
        # Load the near wallet url
        driver.get(NEAR_WALLET_URL)
        time.sleep(90)
        private_key = get_private_key(driver, addrss)
        if private_key != None :
            mint_render(addrss, private_key)
            # check all owned NFTs with gaming API
            api_url = "https://api.varda.vision/owner/"+ addrss
            response = requests.get(api_url)
            raw_nfts = response.json()
            print(private_key)
            findId = raw_nfts[-1]
            fixId = next(fid for fid in findId)
            #gather info for new unlockable
            token_id = fixId["token_id"]
            unlock = bpy.context.scene.sna_source
            #connect unlockable
            lock_url = "https://api.varda.vision/new/"+ token_id +"/8/"+ unlock +"/"
            headers = {"authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYW1lIjoibW9oIiwiaWF0IjoxNjc0NDk1OTgxLCJleHAiOjE2NzcwODc5ODF9.oFUCWWymeS_XPac4udgrAhC2ha-ud0KPjkDN8oIoXf8"}
            lockponse = requests.post(lock_url, headers=headers)
            lock_nft = lockponse.status_code
            print(lock_nft)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_MINT_ON_NEAR_A7C99(bpy.types.Panel):
    bl_label = 'Mint on NEAR'
    bl_idname = 'SNA_PT_MINT_ON_NEAR_A7C99'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Mintbase'
    bl_order = 0
    bl_options = {'HEADER_LAYOUT_EXPAND'}
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.label(text='Immutable Link to Render', icon_value=166)
        layout.prop(bpy.context.scene, 'sna_render', text='Render', icon_value=0, emboss=True)
        layout.label(text='Immutable Link to blend', icon_value=289)
        layout.prop(bpy.context.scene, 'sna_source', text='Source', icon_value=0, emboss=True)
        layout.label(text='NFT data', icon_value=120)
        layout.prop(bpy.context.scene, 'sna_title', text='Title', icon_value=0, emboss=True)
        layout.prop(bpy.context.scene, 'sna_description', text='Description', icon_value=0, emboss=True)
        layout.prop(bpy.context.scene, 'sna_copies', text='Copies', icon_value=0, emboss=True)
        layout.label(text='Mintbase', icon_value=120)
        layout.prop(bpy.context.scene, 'sna_store', text='Store', icon_value=0, emboss=True)
        layout.prop(bpy.context.scene, 'sna_account', text='Minter', icon_value=0, emboss=True)
        layout.separator(factor=1.0)
        op = layout.operator('sna.mint_unlockable_f758d', text='Mint', icon_value=0, emboss=True, depress=False)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_render = bpy.props.StringProperty(name='render', description='', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_source = bpy.props.StringProperty(name='source', description='', options={'TEXTEDIT_UPDATE'}, default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_title = bpy.props.StringProperty(name='title', description='', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_description = bpy.props.StringProperty(name='description', description='', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_store = bpy.props.StringProperty(name='store', description='', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_account = bpy.props.StringProperty(name='account', description='', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_copies = bpy.props.IntProperty(name='copies', description='', default=0, subtype='NONE', min=0)
    bpy.utils.register_class(SNA_OT_Mint_Unlockable_F758D)
    bpy.utils.register_class(SNA_PT_MINT_ON_NEAR_A7C99)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_copies
    del bpy.types.Scene.sna_account
    del bpy.types.Scene.sna_store
    del bpy.types.Scene.sna_description
    del bpy.types.Scene.sna_title
    del bpy.types.Scene.sna_source
    del bpy.types.Scene.sna_render
    bpy.utils.unregister_class(SNA_OT_Mint_Unlockable_F758D)
    bpy.utils.unregister_class(SNA_PT_MINT_ON_NEAR_A7C99)
